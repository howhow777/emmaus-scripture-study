# 完整經文預覽修訂

## 原因與範圍

固定來源與全文搜尋資料已有完整段落，但共用預覽產生器以 `verses[:4]` 裁切；不是兩個特定連結的缺漏。901 處引用中 315 處受影響，586 處原已完整。桌面版另有內外兩個捲動區。

## 修訂

- 全部引用直接顯示全文，保留原有合排節號及明示的異文註。
- 單一捲動區，標題與關閉鈕保留在頂端；滑鼠、手指及鍵盤都可捲動。
- 開啟或切換引用回到第一節；在同一視窗內移動焦點與捲動不重設位置。
- 圖譜頁按 Escape 先關閉預覽，保留選取的研究條目並將焦點還給原連結。
- 若遇到舊快取或缺節，不標成全文，明示資料不完整並保留原網站連結。
- 三頁同步更新預覽 JS、CSS、資料的版本網址。

## 驗證資料

- `preview-completeness.json`：901 處逐項核對固定來源、引用起訖、合排節數、入口及外連對應。
- `preview-browser.json`：真實 Chrome 開啟首頁、覆蓋頁與圖譜動態詳情的經文連結，逐項比對渲染文字；另檢查長段落尾節的實際可見性、捲動與鍵盤／觸控行為。
- 搜尋資料、圖譜研究資料與語意設定和基準版本 `435f765` 逐位元相同；語意 corpus 維持 `4dce84e4f5eb107fa141`。這次不呼叫模型。
- Chrome 觸控模擬需讓原生視窗大於模擬 viewport，否則底緣的 CDP 手勢超出 compositor 有效範圍。測試腳本會設定原生視窗並核對 CSS viewport 不變；沒有因這個測試環境問題加入額外的網頁手勢程式。
- 本次通過 `npm test` 的 43 項 JavaScript、9 項 Python 測試（零跳過），`npm run check:graph`、`npm run audit:previews`，以及 HTTPS 瀏覽器的 86 項操作檢查（涵蓋 901 處引用）。瀏覽器報告記錄已測試資產的 SHA-256，無未捕捉的 JavaScript 錯誤，模型請求數為零。

## 發布狀態

full-preview2 已獲本次 iPhone Safari、Android Chrome 與關閉按鈕驗收通過，已正式發布至 https://howhow777.github.io/emmaus-scripture-study/ 並更新下載包。正式站的 901 處引用與 86 項操作檢查全部通過；雙向跳轉與實際外部經文頁面也已驗證。紀錄見 `preview-device-acceptance.json`、`preview-production.json` 與 `preview-release-links.json`。

## Android 關閉按鈕修訂（full-preview2）

使用者回報 Android 全文預覽正常，另附關閉圖示偏移的截圖。首頁通用 `button` 樣式帶入 `min-height:44px` 及 `padding:9px 16px`，原先 32px 的關閉按鈕因此變成橢圓且文字偏移。關閉按鈕改為明確的 44×44px、零內距，使用格線置中的 SVG 圖示；不依賴字型的乘號字形。三頁同步升級預覽資產版本。

實際瀏覽器核對首頁、圖譜與覆蓋頁，以及三種手機尺寸的捲動後標題：圓框寬高 44px，圖示水平與垂直中心差均為 0px，關閉與全文捲動通過。Android 全文功能、iPhone Safari 全文功能與修訂後按鈕外觀均已由使用者確認通過。
